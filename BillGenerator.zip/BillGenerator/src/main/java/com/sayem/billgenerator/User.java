/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sayem.billgenerator;

/**
 *
 * @author bunnybear
 */
public class User {
    private String name;
    private String phone;
    private int role;
    private String email;
    private int status;
    private int id;
    private String address;
    private String meterNumber;

    public User() {
    }
    
    
      public User(String name, String phone, int role, String email, int status, int id, String address,String meterNumber) {
        this.name = name;
        this.phone = phone;
        this.role = role;
        this.email = email;
        this.status = status;
        this.id = id;
        this.address = address;
        this.meterNumber=meterNumber;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("User{");
        sb.append("name=").append(name);
        sb.append(", phone=").append(phone);
        sb.append(", role=").append(role);
        sb.append(", email=").append(email);
        sb.append(", status=").append(status);
        sb.append(", id=").append(id);
        sb.append(", address=").append(address);
        sb.append(", meterNumber=").append(meterNumber);
        sb.append('}');
        return sb.toString();
    }


      
      
      
      
}


