/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sayem.billgenerator;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;
import javax.naming.Context;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author bunnybear
 */
public class Utils {

    public static void login(int id) {
        Preferences pref = Preferences.userRoot().node("loginInfo");
        pref.putInt("id", (id));
        pref.putBoolean("loggedIn", true);

    }

    public static void logout() {
        try {
            Preferences pref = Preferences.userRoot().node("loginInfo");
            pref.clear();
        } catch (BackingStoreException ex) {
            Logger.getLogger(Utils.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static boolean isLoggedIn() {
        Preferences pref = Preferences.userRoot().node("loginInfo");
        return pref.getBoolean("loggedIn", false);
    }

    public static int getUserId() {
        Preferences pref = Preferences.userRoot().node("loginInfo");
        return pref.getInt("id", -1);
    }

    public static User getUserInfo() {
        int id = getUserId();
        String name;
        String phone;
        int role;
        String email;
        int status;
        String address;
        System.out.println("" + id);
        String meter;
        try {
            String query = "SELECT * FROM `users` where id =" + id;

            Conn c = new Conn();
            ResultSet r = c.s.executeQuery(query);
            if (r.next()) {
                name = r.getString("name");
                phone = r.getString("phone");
                role = r.getInt("role");
                status = r.getInt("status");
                address = r.getString("address");
                meter = r.getString("meterNumber");

                email = r.getString("email");

                return new User(name, phone, role, email, status, id, address, meter);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    public static int showYesNoDialog(Component pc) {
        int result = JOptionPane.showConfirmDialog(pc, "Are you Sure? You want to delete?", "Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE);
        return switch (result) {
            case JOptionPane.YES_OPTION -> 1;
            case JOptionPane.NO_OPTION -> 0;
            default -> -1;
        };
    }

   
    public static User getUserInfo(int id) {
        String name;
        String phone;
        int role;
        String email;
        int status;
        String address;
        System.out.println("" + id);

        String meter;
        try {
            String query = "SELECT * FROM `users` where id =" + id;

            Conn c = new Conn();
            ResultSet r = c.s.executeQuery(query);
            if (r.next()) {
                name = r.getString("name");
                phone = r.getString("phone");
                role = r.getInt("role");
                status = r.getInt("status");
                address = r.getString("address");
                meter = r.getString("meterNumber");

                email = r.getString("email");

                return new User(name, phone, role, email, status, id, address, meter);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
