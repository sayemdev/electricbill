/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.sayem.billgenerator;

import com.sayem.billgenerator.CustomTable.TableActionCellEditor;
import com.sayem.billgenerator.CustomTable.TableActionCellRender;
import com.sayem.billgenerator.CustomTable.TableActionEvent;
import java.awt.Component;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author bunnybear
 */
public class PendingConsumersFrame extends javax.swing.JFrame {

    /**
     * Creates new form ConsumerListFrame
     */
    public PendingConsumersFrame() {
        initComponents();
        getData();

        TableActionEvent event = new TableActionEvent() {
            @Override
            public void onEdit(int row) {
                System.out.println("Edit row : " + row);
                new EditConsumerFrame(model.getValueAt(row, 0).toString()).setVisible(true);
            }

            @Override
            public void onDelete(int row) {
                int result = Utils.showYesNoDialog(PendingConsumersFrame.this);
                if (result == 1) {
                    try {
                        if (consumerTable.isEditing()) {
                            consumerTable.getCellEditor().stopCellEditing();
                        }

                        Conn con = new Conn();
                        String query = "delete from users where id =" + model.getValueAt(row, 0).toString();
                        int r = con.s.executeUpdate(query);

                        if (r == 1) {
                            model.getDataVector().removeAllElements();
                            model.fireTableDataChanged();
                            getData();
                        } else {
                            JOptionPane.showMessageDialog(PendingConsumersFrame.this, "Updating Consumer Info Failed.\nPlease try again");
                        }

                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(PendingConsumersFrame.this, "Updating Consumer Info Failed with error: \n" + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onView(int row) {
                System.out.println("View row : " + row);
            }
        };
        consumerTable.getColumnModel().getColumn(7).setCellRenderer(new TableActionCellRender());
        consumerTable.getColumnModel().getColumn(7).setCellEditor(new TableActionCellEditor(event));
        consumerTable.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable jtable, Object o, boolean bln, boolean bln1, int i, int i1) {
                setHorizontalAlignment(SwingConstants.RIGHT);
                return super.getTableCellRendererComponent(jtable, o, bln, bln1, i, i1);
            }
        });

    }

    public void getData() {
        try {
            consumerTable.setRowHeight(50);

            Conn con = new Conn();
            String query = "select * from users where status==2";
            ResultSet rs = con.s.executeQuery(query);
            model = (DefaultTableModel) consumerTable.getModel();

            String name;
            String phone;
            String email;
            String status;
            String id;
            String address;
            String meterNo;
            while (rs.next()) {
                name = rs.getString("name");
                phone = rs.getString("phone");
                email = rs.getString("email");
                status = rs.getString("status");
                id = rs.getString("id");
                address = rs.getString("address");
                meterNo = rs.getString("meterNumber");

                if (meterNo.isEmpty()) {
                    meterNo = "N/A";
                }
                String[] row = {id, meterNo, name, phone, email, address, status};
                model.addRow(row);
            }

        } catch (SQLException ex) {
            Logger.getLogger(PendingConsumersFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getData(String text) {
        try {
            Conn con = new Conn();
            String query = "select * from users where status==2 and (name like '%" + text + "%' or meterNumber like '%" + text + "%')";
            System.out.println(query);
            ResultSet rs = con.s.executeQuery(query);
            String name;
            String phone;
            String email;
            String status;
            String id;
            String address;
            String meterNo;
            while (rs.next()) {
                name = rs.getString("name");
                phone = rs.getString("phone");
                email = rs.getString("email");
                status = rs.getString("status");
                id = rs.getString("id");
                address = rs.getString("address");
                meterNo = rs.getString("meterNumber");

                if (meterNo.isEmpty()) {
                    meterNo = "N/A";
                }
                String[] row = {id, meterNo, name, phone, email, address, status};
                model.addRow(row);
            }

        } catch (SQLException ex) {
            Logger.getLogger(PendingConsumersFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    DefaultTableModel model;

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        consumerTable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        searchField = new javax.swing.JTextField();
        searchButton = new javax.swing.JLabel();
        addNew = new javax.swing.JButton();
        close = new javax.swing.JButton();
        home = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        jLabel1.setText("Approved Consumers");

        consumerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Meter No.", "Name", "Email", "Phone", "Address", "Status", "Action"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(consumerTable);
        if (consumerTable.getColumnModel().getColumnCount() > 0) {
            consumerTable.getColumnModel().getColumn(5).setPreferredWidth(250);
            consumerTable.getColumnModel().getColumn(7).setPreferredWidth(250);
        }

        jLabel2.setText("Search by Meter Number/Customer Name");

        searchField.setMargin(new java.awt.Insets(2, 16, 2, 16));
        searchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchFieldActionPerformed(evt);
            }
        });

        searchButton.setIcon(new javax.swing.ImageIcon("/Users/bunnybear/Downloads/search.png")); // NOI18N
        searchButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchButtonMouseClicked(evt);
            }
        });

        addNew.setBackground(new java.awt.Color(51, 153, 0));
        addNew.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        addNew.setForeground(new java.awt.Color(255, 255, 255));
        addNew.setText("Add New");
        addNew.setMargin(new java.awt.Insets(8, 24, 8, 24));
        addNew.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewMouseClicked(evt);
            }
        });
        addNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNewActionPerformed(evt);
            }
        });

        close.setBackground(new java.awt.Color(255, 51, 51));
        close.setForeground(new java.awt.Color(255, 255, 255));
        close.setIcon(new javax.swing.ImageIcon("/Users/bunnybear/Downloads/close.png")); // NOI18N
        close.setMargin(new java.awt.Insets(6, 16, 6, 15));
        close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeMouseClicked(evt);
            }
        });

        home.setBackground(new java.awt.Color(51, 153, 255));
        home.setForeground(new java.awt.Color(255, 255, 255));
        home.setIcon(new javax.swing.JLabel() {
            public javax.swing.Icon getIcon() {
                try {
                    return new javax.swing.ImageIcon(
                        new java.net.URL("file:/Users/bunnybear/Downloads/home (1).png")
                    );
                } catch (java.net.MalformedURLException e) {
                }
                return null;
            }
        }.getIcon());
        home.setMargin(new java.awt.Insets(6, 16, 6, 15));
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(357, 357, 357)
                                .addComponent(addNew, javax.swing.GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(home)
                        .addGap(297, 297, 297)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(close)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(home)
                            .addComponent(close))))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(addNew)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(searchButton)
                            .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchButtonMouseClicked
        // TODO add your handling code here:
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged(); // notifies the JTable that the model has changed

        getData(searchField.getText().toLowerCase());
    }//GEN-LAST:event_searchButtonMouseClicked

    private void searchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchFieldActionPerformed

    private void closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeMouseClicked
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_closeMouseClicked

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        // TODO add your handling code here:
        this.dispose();
        new HomePage().setVisible(true);
    }//GEN-LAST:event_homeMouseClicked

    private void addNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNewActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addNewActionPerformed

    private void addNewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewMouseClicked
        // TODO add your handling code here:
        this.dispose();
        new AddConsumerFrame().setVisible(true);
    }//GEN-LAST:event_addNewMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PendingConsumersFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PendingConsumersFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PendingConsumersFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PendingConsumersFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PendingConsumersFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addNew;
    private javax.swing.JButton close;
    private javax.swing.JTable consumerTable;
    private javax.swing.JButton home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel searchButton;
    private javax.swing.JTextField searchField;
    // End of variables declaration//GEN-END:variables
}
